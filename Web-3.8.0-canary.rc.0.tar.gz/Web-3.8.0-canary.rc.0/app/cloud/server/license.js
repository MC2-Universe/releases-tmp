export const LICENSE_VERSION = 2;

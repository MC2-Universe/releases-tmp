import { fileUploadHandler } from './lib/fileUploadHandler';

export {
	fileUploadHandler,
};

import { injectIntoBody } from '../../../ui-master/server';

injectIntoBody('chatpal-enter', Assets.getText('server/asset/chatpal-enter.svg'));
injectIntoBody('chatpal-logo-icon-darkblue', Assets.getText('server/asset/chatpal-logo-icon-darkblue.svg'));

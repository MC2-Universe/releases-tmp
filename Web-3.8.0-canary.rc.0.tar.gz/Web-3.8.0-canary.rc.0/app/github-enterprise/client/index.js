import '../lib/common';
import './github-enterprise-login-button.css';

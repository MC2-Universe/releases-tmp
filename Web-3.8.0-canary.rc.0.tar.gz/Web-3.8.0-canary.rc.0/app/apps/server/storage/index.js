import { AppRealLogsStorage } from './logs-storage';
import { AppRealStorage } from './storage';

export { AppRealLogsStorage, AppRealStorage };

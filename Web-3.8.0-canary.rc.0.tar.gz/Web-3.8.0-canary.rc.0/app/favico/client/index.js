import { Favico } from './favico';

export { Favico };

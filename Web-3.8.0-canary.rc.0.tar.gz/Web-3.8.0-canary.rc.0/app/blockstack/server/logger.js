import { Logger } from '../../logger';

export const logger = new Logger('Blockstack');

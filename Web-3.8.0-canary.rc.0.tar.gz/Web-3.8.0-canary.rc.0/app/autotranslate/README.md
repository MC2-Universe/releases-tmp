# Rocket.Chat Auto Translate

Rocket.Chat supports auto translate through Google Cloud Translation API
Through this you will be able to read messages in your native languages
regardless of language the message was written on.

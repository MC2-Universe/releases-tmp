import './lib/actionButton';
import './lib/tabBar';
import './views/autoTranslateFlexTab.html';
import './views/autoTranslateFlexTab';
import './stylesheets/autotranslate.css';

export { AutoTranslate } from './lib/autotranslate';

import ErrorHandler from './lib/RocketChat.ErrorHandler';
import './startup/settings';

export {
	ErrorHandler,
};

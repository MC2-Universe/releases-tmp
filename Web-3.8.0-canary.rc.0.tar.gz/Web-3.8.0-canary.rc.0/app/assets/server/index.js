export { RocketChatAssets } from './assets';

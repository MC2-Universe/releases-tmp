export const dummyDate = new Date(2015, 4, 19);
